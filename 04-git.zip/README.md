# put_io_lab Stanisław Borowiec
# 26.10.2013
# dodatkowy tekst